#!/bin/bash
# test-endpoints.sh — Test 2Brain payment endpoints

echo "🧪 Testing 2Brain Payment System Endpoints"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

BASE_URL="https://2brain.hoangtiendung.com"

# Test 1: Create Order
echo -e "${YELLOW}Test 1: Create Order${NC}"
echo "POST $BASE_URL/api/create-order-sepay"

RESPONSE=$(curl -s -X POST "$BASE_URL/api/create-order-sepay" \
  -H "Content-Type: application/json" \
  -d '{
    "phone": "0901234567",
    "fullName": "Test User",
    "email": "test@example.com",
    "amount": 299000
  }')

echo "Response:"
echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"

if echo "$RESPONSE" | grep -q '"success":true'; then
  echo -e "${GREEN}✅ PASS: Order created successfully${NC}"
  ORDER_ID=$(echo "$RESPONSE" | grep -o '"orderId":"[^"]*"' | cut -d'"' -f4)
  echo "Order ID: $ORDER_ID"
else
  echo -e "${RED}❌ FAIL: Order creation failed${NC}"
fi

echo ""
echo "---"
echo ""

# Test 2: Webhook (simulate IPN)
echo -e "${YELLOW}Test 2: Webhook (Simulate IPN)${NC}"
echo "POST $BASE_URL/api/webhook-sepay"

if [ -n "$ORDER_ID" ]; then
  WEBHOOK_RESPONSE=$(curl -s -X POST "$BASE_URL/api/webhook-sepay" \
    -H "Content-Type: application/json" \
    -d "{
      \"order_code\": \"$ORDER_ID\",
      \"amount\": 299000,
      \"status\": \"success\"
    }")
else
  # Use fake order ID for testing
  WEBHOOK_RESPONSE=$(curl -s -X POST "$BASE_URL/api/webhook-sepay" \
    -H "Content-Type: application/json" \
    -d '{
      "order_code": "CO1234567890",
      "amount": 299000,
      "status": "success"
    }')
fi

echo "Response:"
echo "$WEBHOOK_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$WEBHOOK_RESPONSE"

if echo "$WEBHOOK_RESPONSE" | grep -q '"success":true'; then
  echo -e "${GREEN}✅ PASS: Webhook processed successfully${NC}"
elif echo "$WEBHOOK_RESPONSE" | grep -q '"error":"Lead not found"'; then
  echo -e "${YELLOW}⚠️  WARNING: Lead not found (expected if order wasn't saved)${NC}"
else
  echo -e "${RED}❌ FAIL: Webhook processing failed${NC}"
fi

echo ""
echo "---"
echo ""

# Test 3: Check Supabase Connection
echo -e "${YELLOW}Test 3: Check Supabase Connection${NC}"

SUPABASE_URL="https://qmmiuqztukpagbuigzma.supabase.co"
SUPABASE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFtbWl1cXp0dWtwYWdidWlnem1hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUwNTc4NzgsImV4cCI6MjA2MDYzMzg3OH0.BVz7sj2b-QlJbmXL-gL1qD8Eay3UzNGzxvOLDdQh0Hw"

SUPABASE_RESPONSE=$(curl -s "$SUPABASE_URL/rest/v1/leads?select=id,email,payment_status&limit=5" \
  -H "apikey: $SUPABASE_KEY" \
  -H "Authorization: Bearer $SUPABASE_KEY")

echo "Latest 5 leads:"
echo "$SUPABASE_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$SUPABASE_RESPONSE"

if echo "$SUPABASE_RESPONSE" | grep -q '\['; then
  echo -e "${GREEN}✅ PASS: Supabase connection working${NC}"
else
  echo -e "${RED}❌ FAIL: Supabase connection failed${NC}"
fi

echo ""
echo "=========================================="
echo "🏁 Tests Complete"
echo ""
echo "📊 Summary:"
echo "- Create Order: Check if QR code URL returned"
echo "- Webhook: Check if payment processed"  
echo "- Supabase: Check if database accessible"
echo ""
echo "🔍 Check Vercel logs for detailed error messages:"
echo "   https://vercel.com/dunghoangtien0504-7276s-projects/logs"
